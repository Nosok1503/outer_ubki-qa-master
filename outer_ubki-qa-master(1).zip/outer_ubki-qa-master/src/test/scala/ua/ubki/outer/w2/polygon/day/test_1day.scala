package ua.ubki.outer.w2.polygon.day

import io.gatling.core.Predef.{global, _}
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._

import java.time.{LocalDate, ZonedDateTime}
import scala.language.postfixOps
import scala.util.Random


class test_1day extends Simulation {

  before {
    println("Simulation is about to start!")
  }

  after {
    println("Simulation is finished!")
  }
  var sessid = ""

  val sessionHeaders = Map("Authorization" -> "${sessid}",
    "Content-Type" -> "application/json",
    "Accept" -> "application/json",
    "user-agent" -> "Gatling Opendata QA: w2OuterPolygonSimulation"
  )

  val sessionHeadersB2 = Map("Authorization" -> "${sessid}",
    "Content-Type" -> "application/xml",
    // "Accept" -> "application/json",
    "Accept" -> "application/xml",

    "user-agent" -> "Gatling Opendata QA: w2OuterPolygonSimulation"
  )

  // private var ubkiSession = ""

  val goodOkpoFeeder: Iterator[Map[String, String]] = Iterator.continually(Map("okpo" -> "2823809705"))
  private var vdate = java.time.LocalDate.now

  private def buildIdent(inn: String, dlstat: String, dlamtexp: String = "0"): Map[String, Any] = {

    val year = 1950 + Random.nextInt(50)
    val month = 1 + Random.nextInt(11)
    val day = 1 + Random.nextInt(27)
    val bDate = LocalDate.of(year, month, day)

    val prev = ZonedDateTime.now.minusDays(1).toLocalDate
    //val prev_1day = ZonedDateTime.now.minusMonths(1).toLocalDate
    val now = java.time.LocalDate.now
    val dlamtcur = Random.nextInt(10000)
    val dlamtpaym = 2 * dlamtcur

    Map(
      "inn" -> inn,
      "dlflstat" -> dlstat,
      //   "sessid" -> sessid,
      "vdate" -> now,
      "currentMonthDealDate" -> now,
      "prevMonthDealDate" -> prev,
      "prevYear" -> prev.getYear,
      "prevMonth" -> prev.getMonthValue,
      "currentYear" -> now.getYear,
      "currentMonth" -> now.getMonthValue)

  }

  val AddDeal = scenario("w2OuterPolygonSimulation Add Ident And Deals")
    .feed(Array(buildIdent("3297003038","2")// открыта
    ).queue)
    .exec{session => session.set("sessid", sessid)}
    .exec(http("w2OuterPolygonSimulation Add Ident And Deals")
      .post("/xml")
      .body(ElFileBody("bodies/in/ok_OuterPoligonTestW2B2_1day.xml"))
      .transformResponse {
        (session, response) =>
          println("Response: " + new String(response.body.string))
          response
      }
      .check(status.is(200))
      .check(regex(""" er="0" """).exists))



  val authHttp = http("auth")

    .post("https://test.ubki.ua/b2_api_xml/ubki/auth")
    //    .post("https://secure.ubki.ua/b2_api_xml/ubki/auth")
    .header(HttpHeaderNames.Accept, HttpHeaderValues.ApplicationJson)
    .header(HttpHeaderNames.ContentType, HttpHeaderValues.ApplicationXml)
    .body(StringBody("""{"doc": {"auth": { "login" : "outer_ubki_qa_test", "pass": "outer_ubki_qa_test" } } }"""))

  val authScenario: ScenarioBuilder = scenario("AuthToUbki")
    .exec(authHttp
      .transformResponse {
        (session, response) =>
          println("AuthResponse: " + new String(response.body.string))
          response
      }
      .check(status.is(200), xpath("/doc/auth/@sessid").find.saveAs("sessid")))
    .exitHereIfFailed
    .exec{session => { sessid = session("sessid").as[String]
      println("AuthResponse: " + new String(sessid) )
      session}}


  val httpProtocol = http.baseUrl("https://test.ubki.ua/upload/data")

  val httpProtocolB2 = http.baseUrl("https://test.ubki.ua/b2_api_xml/ubki")






  val DeletePostcondition = scenario("w2OuterPolygonSimulation DeletePostcondition")
    .feed(Array(buildIdent("3297003038","2")
    ).queue)
    .exec{session => session.set("sessid", sessid)}
    .exec(http("validate_DeletePostcondition")
      .post("/xml")
      .body(ElFileBody("bodies/in/del_OuterPoligonTestW2B2_1day.xml"))
      .transformResponse {
        (session, response) =>
          println("Response: " + new String(response.body.string))
          response
      }
      .check(status.is(200))
      .check(regex(""" er="0" """).exists))




  val CheckB2Deal = scenario("w2OuterPolygonSimulation CheckB2Deal")
    .exec{session => session.set("sessid", sessid)}
    .exec(http("validate_B2_scenario CheckB2_Deal")
      .post("/xml")
      .headers(sessionHeadersB2)
      .transformResponse {
        (session, response) =>
          println("Response: " + new String(response.body.string))
          response
      }
      .body(ElFileBody("bodies/in/Requvest10Shablon.xml"))
      .check(status.is(200))

      .check(regex("3297003038").exists)
      .check(regex("ТестРаботоспособностиW2B2 1day "+vdate).exists))



  val R2scenario = scenario("R2scenario")
    .exec{session => session.set("sessid", sessid)}


  setUp(

    authScenario.inject(
      atOnceUsers(1)
    ).protocols(httpProtocol)
      .andThen( DeletePostcondition.inject(
        //nothingFor(5 seconds),
        atOnceUsers(1)
      ).protocols(httpProtocol)
        .andThen( AddDeal.inject(
          //nothingFor(15 seconds),
          atOnceUsers(1)
        ).protocols(httpProtocol)
          .andThen( CheckB2Deal.inject(
            //nothingFor(15 seconds),
            constantUsersPerSec(0.05).during(3580)
          ).protocols(httpProtocolB2)

          )
        )
      )
  ).assertions(
    global.failedRequests.count.lt(3),
    //forAll.responseTime.max.lt(1000),
    //details("validate_DeletePostcondition").responseTime.max.lt(1000),

    details("auth").responseTime.max.lt(1000),
    details("validate_DeletePostcondition").responseTime.max.lt(1000),
    details("w2OuterPolygonSimulation Add Ident And Deals").responseTime.max.lt(6000),
    details("validate_B2_scenario CheckB2_Deal").responseTime.max.lt(30000)
  )

}



